var index = require('./index.js');

index.handler();
